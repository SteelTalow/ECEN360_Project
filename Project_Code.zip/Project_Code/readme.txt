This folder contains the two jupyter notebook python files, the html for the basic website, 
and an additional folder for the python scripts to run the neuralnet project on Grace. 

The neural net folder noteably does not contain details for which modules are neccesary to
be loaded in Grace. 